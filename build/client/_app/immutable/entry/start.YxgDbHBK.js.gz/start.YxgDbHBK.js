import{l as o,a as r}from"../chunks/D039e0LN.js";export{o as load_css,r as start};
